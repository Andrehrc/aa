﻿using System.Collections.Generic;
using System.Linq;

namespace BlazorApp1.Data
{
    public class AutorService
    {
        private readonly AppDBContext _db;
        public AutorService(AppDBContext db)
        {
            _db = db;
        }

        // Operações CRUD(Create, Read, Update e Delete)
        // Obter todos os autores
        public List<Autor> GetAutor()
        {
            var autorList = _db.Autores.ToList();
            return autorList;
        }
        // Inserir um Autor
        public string Create(Autor objAutor)
        {
            _db.Autores.Add(objAutor);
            _db.SaveChanges();
            return "Autor salvo com sucesso";
        }
        // Obter um Autor pelo Id
        public Autor GetAutorById(int id)
        {
            Autor objAutor = _db.Autores.FirstOrDefault(a => a.Id == id);
            return objAutor;
        }
        // Atualizar um Autor
        public string UpdateAutor(Autor objAutor)
        {
            _db.Autores.Update(objAutor);
            _db.SaveChanges();
            return "Autor atualizado com sucesso";
        }
        // Remover um Autor
        public string DeleteAutor(Autor objAutor)
        {
            _db.Autores.Remove(objAutor);
            _db.SaveChanges();
            return "Autor removido com sucesso";
        }
    }
}
