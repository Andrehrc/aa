﻿using System.Collections.Generic;
using System.Linq;

namespace BlazorApp1.Data
{
    public class LivroService
    {
        private readonly AppDBContext _db;
        public LivroService(AppDBContext db)
        {
            _db = db;
        }
        // Operações CRUD (Create, Read, Update e Delete)
        // Obter todos os livros
        public List<Livro> GetLivro()
        {
            var livroList = _db.Livros.ToList();
            return livroList;
        }
        // Inserir um Livro
        public string Create(Livro objLivro)
        {
            _db.Livros.Add(objLivro);
            _db.SaveChanges();
            return "Livro salvo com sucesso";
        }
        // Obter um Livro pelo Id
        public Livro GetLivroById(int id)
        {
            Livro objLivro = _db.Livros.FirstOrDefault(l => l.Id == id);
            return objLivro;
        }
        // Atualizar um Livro
        public string UpdateLivro(Livro objLivro)
        {
            _db.Livros.Update(objLivro);
            _db.SaveChanges();
            return "Livro atualizado com sucesso";
        }
        // Remover um Livro
        public string DeleteLivro(Livro objLivro)
        {
            _db.Livros.Remove(objLivro);
            _db.SaveChanges();
            return "Livro removido com sucesso";
        }
    }
}
