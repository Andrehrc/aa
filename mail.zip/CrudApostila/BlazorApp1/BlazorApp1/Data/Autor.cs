﻿namespace BlazorApp1.Data
{
    public class Autor
    {
        public int Id { get; set; }
        public string NomeCompleto { get; set; }
        public string Nacionalidade { get; set; }
    }
}
