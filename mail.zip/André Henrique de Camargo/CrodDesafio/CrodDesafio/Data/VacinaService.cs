﻿using System.Collections.Generic;
using System.Linq;

namespace CrodDesafio.Data
{
    public class VacinaService
    {
        private readonly AppDBContext _db;
        public VacinaService(AppDBContext db)
        {
            _db = db;
        }

        // Operações CRUD(Create, Read, Update e Delete)
        // Obter todos as Vacinas
        public List<VacinaCovid19> GetVacina()
        {
            var VacinaList = _db.Vacinas.ToList();
            return VacinaList;
        }
        // Inserir uma Vacina
        public string Create(VacinaCovid19 objVacina)
        {
            _db.Vacinas.Add(objVacina);
            _db.SaveChanges();
            return "Vacina salva com sucesso";
        }
        // Obter uma Vacina pelo Id
        public VacinaCovid19 GetVacinaById(int id)
        {
            VacinaCovid19 objVacina = _db.Vacinas.FirstOrDefault(a => a.Id == id);
            return objVacina;
        }
        // Atualizar uma Vacina
        public string UpdateVacina(VacinaCovid19 objVacina)
        {
            _db.Vacinas.Update(objVacina);
            _db.SaveChanges();
            return "Vacina atualizada com sucesso";
        }
        // Remover uma Vacina
        public string DeleteAutor(VacinaCovid19 objVacina)
        {
            _db.Vacinas.Remove(objVacina);
            _db.SaveChanges();
            return "Vacina removida com sucesso";
        }
    }
}
