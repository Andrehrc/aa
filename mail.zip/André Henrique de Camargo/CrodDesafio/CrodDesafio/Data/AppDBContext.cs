﻿using Microsoft.EntityFrameworkCore;

namespace CrodDesafio.Data
{
    public class AppDBContext: DbContext
    {
       public AppDBContext(DbContextOptions<AppDBContext>options) :base(options)
        {
        }
        public DbSet<VacinaCovid19> Vacinas { get; set; }
    }
}

