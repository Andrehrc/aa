﻿namespace CrodDesafio.Data
{
    public class VacinaCovid19
    {
        public int Id { get; set; }
        public string NomeVacina { get; set; }
        public string Fabricante { get; set; }
        public string PaisOrigem { get; set; }
        public int QuantidadeMinimaDoses { get; set; }
        public int PercentualEficaciaComprovada { get; set; }
        public double PrecoVendaPorDose { get; set; }

    }
}
