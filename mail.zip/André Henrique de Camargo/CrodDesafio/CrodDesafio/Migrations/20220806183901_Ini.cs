﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace CrodDesafio.Migrations
{
    public partial class Ini : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Vacinas",
                columns: table => new
                {
                    id = table.Column<int>(type: "INTEGER", nullable: false)
                        .Annotation("Sqlite:Autoincrement", true),
                    NomeVacina = table.Column<string>(type: "TEXT", nullable: true),
                    Fabricante = table.Column<string>(type: "TEXT", nullable: true),
                    PaisOrigem = table.Column<string>(type: "TEXT", nullable: true),
                    QuantidadeMinimaDoses = table.Column<int>(type: "INTEGER", nullable: false),
                    PercentualEficaciaComprovada = table.Column<int>(type: "INTEGER", nullable: false),
                    PrecoVendaPorDose = table.Column<double>(type: "REAL", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vacinas", x => x.id);
                });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Vacinas");
        }
    }
}
